__version__ = '0.1.6b1'

from birdspotter.BirdSpotter import BirdSpotter
