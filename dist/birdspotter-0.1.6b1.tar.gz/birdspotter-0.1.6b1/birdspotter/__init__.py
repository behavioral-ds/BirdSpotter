__version__ = '0.1.5b1'

from birdspotter.BirdSpotter import BirdSpotter
