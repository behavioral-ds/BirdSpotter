# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['birdspotter']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'birdspotter',
    'version': '0.1.0',
    'description': 'A package which provides an influence and bot detection toolkit for twitter',
    'long_description': None,
    'author': 'Rohit Ram',
    'author_email': 'rohit.ram@anu.edu.au',
    'url': None,
    'packages': packages,
    'package_data': package_data,
}


setup(**setup_kwargs)
